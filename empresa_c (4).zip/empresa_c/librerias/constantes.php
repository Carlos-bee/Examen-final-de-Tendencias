<?php
session_name();
session_start();

const IP_MAQUINA='127.0.0.1';
const BASE_DE_DATOS='personas';

const SEL_C='sel_c';
const CLAVE_SEL_C='sel_c';

const ALL_C='all_c';
const CLAVE_ALL_C='all_c';
?>