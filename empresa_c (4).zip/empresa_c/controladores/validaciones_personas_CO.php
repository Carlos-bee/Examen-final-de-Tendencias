<?php


class validacion_personas
{

    function validar ($pais_id_nacionalidad, $pais_id_pregrado, $sexo_id, $reli_id,$pers_documento,$pers_nombres, $pers_apellidos, $pers_fecha_nacimiento,$pers_email,$pers_direccion,$pers_celular)
    {
        $patron_texto = "/^[a-zA-ZáéíóúÁÉÍÓÚäëïöüÄËÏÖÜàèìòùÀÈÌÒÙ\s]+$/";
        
        if(empty($pais_id_nacionalidad))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: selecciona del pais de nacionalidad ",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
              
        if(empty($pais_id_pregrado))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: selecciona del pais de pregrado",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
              
        if(empty($sexo_id))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: seleccionar el sexo",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        if(empty($reli_id))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: seleccionar la religi&oacute;n",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        if(empty($pers_documento))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe ingresar el n&uacute;mero de documento",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        if(empty($pers_nombres))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe llenar el campo nombres",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        }    
        if(empty($pers_apellidos))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe llenar el campo apellidos",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        }
        if(empty($pers_fecha_nacimiento))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe seleccionar la fecha de nacimiento",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        }
        if(empty($pers_email))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"se debe llenar el campo del correo electr&oacute;nico",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        } 
        if(empty($pers_direccion))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe llenar el campo direcci&oacute;n",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        }
        if(empty($pers_celular))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: se debe llenar el campo celular",
        
            ];
                exit(json_encode($arreglo_respuesta));
        
        }

        if(!is_numeric($pers_documento))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Solo se admiten NUMEROS en el documento",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }

      
        if(!preg_match($patron_texto,$pers_nombres))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Solo se admiten LETRAS en el nombre(s)",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        if(!preg_match($patron_texto,$pers_apellidos))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Solo se admiten LETRAS en el apellido(s)",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        if(!filter_var($pers_email, FILTER_VALIDATE_EMAIL))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"ERROR: sintaxis equivocada, revisa el correo electr&oacute;nico",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }

        if(!is_numeric($pers_celular))
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Solo se admiten NUMEROS en el n&uacute;mero de celular",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }

        $size_pers_documento=strlen($pers_documento);
        if($size_pers_documento>15)
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Se excedi&oacute; en la cantidad de car&aacute;cteres del documento",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        $size_pers_nombres=strlen($pers_nombres);
        if($size_pers_nombres>50)
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Se excedi&oacute; en la cantidad de car&aacute;cteres en el campo nombres",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        $size_pers_apellidos=strlen($pers_apellidos);
        if($size_pers_apellidos>50)
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Se excedi&oacute; en la cantidad de car&aacute;cteres en el campo apellidos",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
        $size_pers_apellidos=strlen($pers_apellidos);
        if($size_pers_apellidos>50)
        {
            $arreglo_respuesta=[
                "estado"=>"ERROR",
               
                "mensaje"=>"Se excedi&oacute; en la cantidad de car&aacute;cteres en el campo apellidos",
        
            ];
                exit(json_encode($arreglo_respuesta));
        }
    }
}



?>